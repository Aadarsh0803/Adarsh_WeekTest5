﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class Purchase
    {
        [Key]
        [Required]
        [StringLength(4)]
        public string PurchaseNo { get; set; }

        public DateTime? PurchaseDate { get; set; }

        public int Quantity { get; set; }

        [ForeignKey("Item")]
        public string ItemCode { get; set; }
        public Item Item { get; set; }

        [ForeignKey("Suplier")]
        public string SuplierNo { get; set; }
        public Suplier Suplier { get; set; }
    }
}
