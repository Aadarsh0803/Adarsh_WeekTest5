﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class POPSContext : DbContext
    {
        private IConfiguration _configuration;

        //Add this for connecting json connection (Dependency Injection) for all entities and controllers
        public POPSContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public DbSet<Purchase> Purchases { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Suplier> Supliers { get; set; }

     

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("POPSConnection"));
        }
    }
}
