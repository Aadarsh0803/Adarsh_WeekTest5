﻿using System.ComponentModel.DataAnnotations;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class Item
    {
        [Key]
        [Required]
        public string ItemCode { get; set; }
        [Required]
        public string ItemName { get; set; }
        [Required]
        
        public int Cost { get; set; }
        //public ICollection<PoMaster> PoMasters { get; set; }
    }
}
