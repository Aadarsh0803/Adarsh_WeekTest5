﻿using System.ComponentModel.DataAnnotations;

namespace Purchase_Order_Processing_System_POPS_.Entities
{
    public class Suplier
    {
        [Key]
        [Required]
        [StringLength(4)]
        public string SuplierNo { get; set; }

        [Required]
        [StringLength(15)]
        public string SuplierName { get; set; }

        [Required]
        [StringLength(40)]
        public string SuplierAddress { get; set; }
    }
}
