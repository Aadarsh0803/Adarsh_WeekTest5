﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Purchase_Order_Processing_System_POPS_.Migrations
{
    /// <inheritdoc />
    public partial class Purchase : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Purchases",
                columns: table => new
                {
                    PurchaseNo = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: false),
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    ItemCode = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    SuplierNo = table.Column<string>(type: "nvarchar(4)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Purchases", x => x.PurchaseNo);
                    table.ForeignKey(
                        name: "FK_Purchases_Items_ItemCode",
                        column: x => x.ItemCode,
                        principalTable: "Items",
                        principalColumn: "ItemCode",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Purchases_Supliers_SuplierNo",
                        column: x => x.SuplierNo,
                        principalTable: "Supliers",
                        principalColumn: "SuplierNo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Purchases_ItemCode",
                table: "Purchases",
                column: "ItemCode");

            migrationBuilder.CreateIndex(
                name: "IX_Purchases_SuplierNo",
                table: "Purchases",
                column: "SuplierNo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Purchases");
        }
    }
}
