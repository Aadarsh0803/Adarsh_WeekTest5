﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Purchase_Order_Processing_System_POPS_.Migrations
{
    /// <inheritdoc />
    public partial class Suplier : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Supliers",
                columns: table => new
                {
                    SuplierNo = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: false),
                    SuplierName = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    SuplierAddress = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Supliers", x => x.SuplierNo);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Supliers");
        }
    }
}
