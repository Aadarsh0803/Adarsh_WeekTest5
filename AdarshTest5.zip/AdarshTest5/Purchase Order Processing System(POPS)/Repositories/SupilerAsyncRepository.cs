﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public class SuplierAsyncRepository : ISuplierAsyncRepository
    {
        private readonly POPSContext _context;

        public SuplierAsyncRepository(POPSContext context)
        {
            _context = context;
        }

        public async Task AddSuppliers(Suplier suplier)
        {
            await _context.Supliers.AddAsync(suplier);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteSuppliers(string SuplierNo)
        {
            var suplier = await _context.Supliers.FindAsync(SuplierNo);
            if (suplier != null)
            {
                _context.Supliers.Remove(suplier);
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("No Supplier found");
            }
        }

        public async Task<List<Suplier>> GetAllSuppliers()
        {
            return await _context.Supliers.ToListAsync();
        }

        public async Task UpdateSuplier(Suplier suplier)
        {
            _context.Supliers.Update(suplier);
            await _context.SaveChangesAsync();
        }
    }
}
