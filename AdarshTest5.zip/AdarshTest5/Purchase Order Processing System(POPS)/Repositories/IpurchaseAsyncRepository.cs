﻿using Purchase_Order_Processing_System_POPS_.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public interface IpurchaseAsyncRepository
    {
        Task<List<Purchase>> GetAll();
        Task Add(Purchase purchase);
        Task Update(Purchase purchase);
        Task Delete(string purchaseNo);
    }
}
