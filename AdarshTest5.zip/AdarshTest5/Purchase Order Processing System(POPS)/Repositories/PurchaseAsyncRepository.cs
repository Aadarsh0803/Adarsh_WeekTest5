﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System_POPS_.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public class PurchaseAsyncRepository : IpurchaseAsyncRepository
    {
        private readonly POPSContext _context;

        public PurchaseAsyncRepository(POPSContext context)
        {
            _context = context;
        }

        public async Task Add(Purchase purchase)
        {
            await _context.Purchases.AddAsync(purchase);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string purchaseNo)
        {
            var purchase = await _context.Purchases.FindAsync(purchaseNo);
            if (purchase != null)
            {
                _context.Purchases.Remove(purchase);
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Purchase not found.");
            }
        }

        public async Task<List<Purchase>> GetAll()
        {
            return await _context.Purchases.ToListAsync();
        }

        public async Task Update(Purchase purchase)
        {
            _context.Purchases.Update(purchase);
            await _context.SaveChangesAsync();
        }
    }
}
