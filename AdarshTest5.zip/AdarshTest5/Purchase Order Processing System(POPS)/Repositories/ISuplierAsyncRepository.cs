﻿using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public interface ISuplierAsyncRepository
    {
        public Task<List<Suplier>> GetAllSuppliers();
        public Task AddSuppliers(Suplier suplier);
        public Task UpdateSuplier(Suplier suplier );
        public Task DeleteSuppliers(string SuplierNo);
    }
}
