﻿using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Migrations;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public class ItemAsyncRepository:IItemAsyncRepository
    {
        private readonly POPSContext _context;

        public ItemAsyncRepository(POPSContext context)
        {
            _context = context;
        }

        public async Task AddItem(Item item)
        {
            await _context.Items.AddAsync(item);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteItem(string ItemCode)
        {
            var item = await _context.Items.FindAsync(ItemCode);
            if (item != null)
            {
                _context.Items.Remove(item);
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("No item found");
            }
        }

        public async Task<List<Item>> GetAllItems()
        {
            return  _context.Items.ToList();
        }

        public async Task UpdateItem(Item item)
        {
            _context.Items.Update(item);
            await _context.SaveChangesAsync();
        }
    }
}
