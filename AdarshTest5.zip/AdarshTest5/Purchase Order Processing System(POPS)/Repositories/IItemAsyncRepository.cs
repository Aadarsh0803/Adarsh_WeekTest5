﻿using Purchase_Order_Processing_System_POPS_.Entities;

namespace Purchase_Order_Processing_System_POPS_.Repositories
{
    public interface IItemAsyncRepository
    {
        public Task<List<Item>> GetAllItems();
        public Task AddItem(Item item);
        public Task UpdateItem(Item item);
        public Task DeleteItem(string ItemCode);
    }
}
