﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Repositories;
using System.Threading.Tasks;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseController : ControllerBase
    {
        private readonly IpurchaseAsyncRepository _purchaseAsyncRepository;

        public PurchaseController(IpurchaseAsyncRepository purchaseAsyncRepository)
        {
            _purchaseAsyncRepository = purchaseAsyncRepository;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var purchases = await _purchaseAsyncRepository.GetAll();
            return Ok(purchases);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> Add(Purchase purchase)
        {
            await _purchaseAsyncRepository.Add(purchase);
            return Ok(purchase);
        }

        [HttpPut("Update/{purchaseNo}")]
        public async Task<IActionResult> Update(string purchaseNo, Purchase purchase)
        {
            if (purchaseNo != purchase.PurchaseNo)
            {
                return BadRequest("Purchase number mismatch.");
            }
            await _purchaseAsyncRepository.Update(purchase);
            return StatusCode(200, purchase);
        }

        [HttpDelete("Delete/{purchaseNo}")]
        public async Task<IActionResult> Delete(string purchaseNo)
        {
            try
            {
                await _purchaseAsyncRepository.Delete(purchaseNo);
                return NoContent();
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
