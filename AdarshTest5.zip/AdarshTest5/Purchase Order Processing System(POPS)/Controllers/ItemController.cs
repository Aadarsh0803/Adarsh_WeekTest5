﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Migrations;
using Purchase_Order_Processing_System_POPS_.Repositories;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemAsyncRepository itemAsyncRepository;
        private IConfiguration _configuration;
        public ItemController(ItemAsyncRepository itemAsyncRepository, IConfiguration configuration)
        {
            this.itemAsyncRepository = itemAsyncRepository;
            _configuration = configuration;
        }

        [HttpGet,Route("GetAll")]
        public async Task<IActionResult> Get()
        {
            var item = await itemAsyncRepository.GetAllItems();
            return Ok(item);
        }
        [HttpPost,Route("AddItem")]
        public async Task<IActionResult> AddItem(Item item)
        {
            await itemAsyncRepository.AddItem(item);
            return Ok(item);
        }
        [HttpPut,Route("UpdateItem")]
        public async Task<IActionResult> updateItem(Item item)
        {
            await itemAsyncRepository.UpdateItem(item);
            return Ok(item);
        }
        [HttpDelete, Route("DeleteItem/{id}")]
        public async Task<IActionResult> DeleteItem(string id)
        {
            try
            {
                await itemAsyncRepository.DeleteItem(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return NotFound();
            }
        }

    }
}
