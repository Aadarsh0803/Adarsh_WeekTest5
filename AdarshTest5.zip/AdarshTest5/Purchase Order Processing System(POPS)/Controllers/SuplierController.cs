﻿using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Repositories;

namespace Purchase_Order_Processing_System_POPS_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SuplierController : ControllerBase
    {
        private readonly ISuplierAsyncRepository _suplierAsyncRepository;
        private readonly IConfiguration _configuration;

        public SuplierController(ISuplierAsyncRepository suplierAsyncRepository, IConfiguration configuration)
        {
            _suplierAsyncRepository = suplierAsyncRepository;
            _configuration = configuration;
        }

        [HttpGet("GetAllSupliers")]
        public async Task<IActionResult> GetAllSuppliers()
        {
            var supliers = await _suplierAsyncRepository.GetAllSuppliers();
            return Ok(supliers);
        }

        [HttpPost("AddSuplier")]
        public async Task<IActionResult> AddSuplier(Suplier suplier)
        {
            await _suplierAsyncRepository.AddSuppliers(suplier);
            return Ok(suplier);
        }

        [HttpPut("UpdateSuplier/{SuplierNo}")]
        public async Task<IActionResult> UpdateSuplier(Suplier suplier)
        {
            await _suplierAsyncRepository.UpdateSuplier(suplier);
            return StatusCode(200, suplier);
        }

        [HttpDelete("DeleteSuplier/{SuplierNo}")]
        public async Task<IActionResult> DeleteSuplier(string SuplierNo)
        {
            try
            {
                await _suplierAsyncRepository.DeleteSuppliers(SuplierNo);
                return NoContent();
            }
            catch (Exception ex)
            {
                return NotFound();
            }
        }
    }
}
