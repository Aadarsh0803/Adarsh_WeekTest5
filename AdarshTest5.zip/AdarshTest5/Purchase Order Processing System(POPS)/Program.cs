
using Purchase_Order_Processing_System_POPS_.Entities;
using Purchase_Order_Processing_System_POPS_.Repositories;

namespace Purchase_Order_Processing_System_POPS_
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Services.AddDbContext<POPSContext>();
            builder.Services.AddTransient<ISuplierAsyncRepository, SuplierAsyncRepository>();
            builder.Services.AddTransient<IItemAsyncRepository, ItemAsyncRepository>();
            builder.Services.AddTransient<IpurchaseAsyncRepository, PurchaseAsyncRepository>();
            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
